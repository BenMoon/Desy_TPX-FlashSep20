class IndexPositions:
    """ Positions of certain values in the X-input-matrix"""
    X_INDEX = 0
    Y_INDEX = 1
    TOF_INDEX = 2
    TOT_INDEX = 3
    LABEL_INDEX = 4