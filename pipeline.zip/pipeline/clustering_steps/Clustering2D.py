from abc import abstractmethod

import cv2
import numpy as np

from pipeline.PipelineStepGrouped import PipelineStepGrouped
from pipeline.PipelineStepGroupedMergeColumns import PipelineStepGroupedMergeColumns
from pipeline.ProcessingIn2D import ProcessingIn2D
from pipeline.label_allocation.AllocationStrategy import AllocationStrategy
from pipeline.label_allocation.NearestNeighborAllocationStrategy import NearestNeighborAllocationStrategy


class Clustering2D(PipelineStepGroupedMergeColumns, ProcessingIn2D):

    def __init__(self, size_limit=0, shape_ratio_limit=0, strategy_2D_mapping=ProcessingIn2D.build_2D_image_reduced,
                 strategy_label_allocation: AllocationStrategy = NearestNeighborAllocationStrategy(),
                 *args, **kwargs):
        self.size_limit = size_limit
        self.shape_ratio_limit = shape_ratio_limit
        self.strategy_2D_mapping = strategy_2D_mapping
        self.strategy_label_allocation = strategy_label_allocation
        super(Clustering2D, self).__init__(*args, **kwargs)

    @staticmethod
    def __calculate_cluster_shape_ratio(points):
        """ Calculate the Shape of the cluster. The Shape is the defined by the ratio of width and height of the cluster.
        The height and the width is defined as the height and width of the min area reactangle in 2D. The Shape will be calculated
        using only two dimensions (x and y) instead of four."""

        def _ratio(x, y):
            """ Calculates the ratio of x and y. The calculation is commutative. The ratio will always be > 1! """
            # TODO: There are situations where the points of a cluster from DBSCAN have a straight shape. Due to this it is possible that 
            # that all values for x or y in this cluster are equal resulting in a width or height of zero.
            # We need to find a proper solution to check if this is the case and handle those cases.
            # In my opinion thos type of clusters should run through edge detection in any case! One possible solution would be to check whether 
            # x or y is 0 and return a very high ratio in this case. This should be Implemented BEFORE calculationg the ratio!
            if x > y:
                if y == 0:
                    y = 1  # print(points)
                return x / y
            else:
                if x == 0:
                    x = 1
                return y / x

        # Documentation: https://docs.opencv.org/master/dd/d49/tutorial_py_contour_features.html
        # 7.b. Rotated Rectangle
        rect = cv2.minAreaRect(points)
        # (center(x, y), (width, height), angle of rotation)
        (x, y), (width, height), angle = rect
        return _ratio(width, height)

    @abstractmethod
    def find_centres(self, image_2D):
        pass

    def process_group(self, group):
        shape_ratio = Clustering2D.__calculate_cluster_shape_ratio(
            group[:, :2].astype(np.int))  # openvc cant handle floating point points

        num_rows, _ = group.shape

        if num_rows > self.size_limit or shape_ratio > self.shape_ratio_limit:
            image_2D, shift_x, shift_y = self.strategy_2D_mapping(group)
            center_points = self.find_centres(image_2D)

            if len(center_points) > 0:
                center_points[:, 0] = center_points[:, 0] + shift_x
                center_points[:, 1] = center_points[:, 1] + shift_y

                return self.strategy_label_allocation.allocate(group, center_points)
            else:
                return np.column_stack((group, np.repeat(-1.0, num_rows)))
        else:
            return np.column_stack((group, np.repeat(PipelineStepGrouped.INITIAL_LABEL, num_rows)))

